namespace Aula10DB.Database;

class DatabaseConfig
{
    public string ConnectionString { get => "Data Source=database.db"; }
}
